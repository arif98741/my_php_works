<?php

require_once('tcpdf_include.php');

// extend TCPF with custom functions
class MYPDF extends TCPDF {

    // Load table data from file
    public function LoadData($file) {
        // Read file lines
        $lines = file($file);
        $data = array();
        foreach ($lines as $line) {
            $data[] = explode(';', chop($line));
        }
        return $data;
    }

    // Colored table
    public function ColoredTable($header, $data) {
        // Colors, line width and bold font
        $this->SetFillColor(20, 0, 0);
        $this->SetTextColor(255);
        $this->SetDrawColor(1, 0, 0);
        $this->SetLineWidth(0.3);
        $this->SetFont('', 'B');
        // Header
        $w = array(22, 27, 18, 40, 65, 55, 23, 23);
        $num_headers = count($header);
        for ($i = 0; $i < $num_headers; ++$i) {
            $this->Cell($w[$i], 7, $header[$i], 1, 0, 'C', 1);
        }
        $this->Ln();
        // Color and font restoration
        $this->SetFillColor(224, 235, 255);
        $this->SetTextColor(0);
        $this->SetFont('');
        // Data
        $fill = 0;
        $con = new mysqli('localhost', 'root', '', 'routine_management');
        if ($con) {
            $sql = "select * from routine"; // this query for fetching data from server
            $query = $con->query($sql);
            if ($query) {
                while ($row = $query->fetch_assoc()) {

                    $this->Cell($w[0], 6, date('d-m-y', strtotime($row['Time Slot'])), 'LR', 0, 'L', $fill);
                    $this->Cell($w[1], 6, $row['Day'], 'LR', 0, 'L', $fill);
                    $this->Cell($w[2], 6, $row['LT'], 'LR', 0, 'L', $fill);
                    $this->Cell($w[3], 6, $row['CCode'], 'LR', 0, 'L', $fill);
                    $this->Cell($w[4], 6, $row['CTitle'], 'LR', 0, 'L', $fill);
                    $this->Cell($w[5], 6, $row['Invigilator'], 'LR', 0, 'L', $fill);
                    $this->Cell($w[6], 6, $row['Room'], 'LR', 0, 'R', $fill);
                    $this->Cell($w[7], 6, $row['Size'], 'LR', 0, 'R', $fill);
                    $this->Ln();
                    $fill = !$fill;
                }
            } else {
                echo "Failed To Load PDF Document";
            }
        }

        $this->Cell(array_sum($w), 0, '', 'T');
    }

}

// create new PDF document
$pdf = new MYPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

// set document information
$pdf->SetCreator(PDF_CREATOR);
$pdf->SetAuthor('DIU');
$pdf->SetTitle('DIU Invigilator Routine Summer Final 2017');
$pdf->SetSubject('DIU Invigalator Routine');
$pdf->SetKeywords('TCPDF, PDF, example, test, guide');

// set default header data
$pdf->SetHeaderData(PDF_HEADER_LOGO, PDF_HEADER_LOGO_WIDTH, PDF_HEADER_TITLE . '', PDF_HEADER_STRING);

// set header and footer fonts
$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));

// set default monospaced font
$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);

// set margins
$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
$pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
$pdf->SetFooterMargin(PDF_MARGIN_FOOTER);

// set auto page breaks
$pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);

// set image scale factor
$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);

// set some language-dependent strings (optional)
if (@file_exists(dirname(__FILE__) . '/lang/eng.php')) {
    require_once(dirname(__FILE__) . '/lang/eng.php');
    $pdf->setLanguageArray($l);
}

// ---------------------------------------------------------
// set font
$pdf->SetFont('helvetica', '', 12);

// add a page
$pdf->AddPage();


//html page content
$html = <<<EOF
<div style="background-color:#fff; color:white;  margin-top: 10px;">

</div>
<pre style="background-color:#fff;color:white; margin-top: 10px;">
int main() {
    printf("HelloWorld");
    return 0;
        
}
</pre>
<br />
       
<div style="color:#000; border: 1px solid red; font-size: 14px;">
    <h5>Teacher Initial</h5>
    <p style="margin-top:2px; ">MRR=Mahfuzur Rahman Raju, RH=Reduanul Haque, TK=Tania Khatun, ABA= Amatul Bushra Akhi, MRR=Mahfuzur Rahman Raju, RH=Reduanul Haque, TK=Tania Khatun, ABA= Amatul Bushra Akhi, MRR=Mahfuzur Rahman Raju, RH=Reduanul Haque, TK=Tania Khatun, ABA= Amatul Bushra AkhiMRR=Mahfuzur Rahman Raju, RH=Reduanul Haque, TK=Tania Khatun, ABA= Amatul Bushra Akhi,MRR=Mahfuzur Rahman Raju, RH=Reduanul Haque, TK=Tania Khatun, ABA= Amatul Bushra Akhi, MRR=Mahfuzur Rahman Raju, RH=Reduanul Haque, TK=Tania Khatun, ABA= Amatul Bushra Akhi, MRR=Mahfuzur Rahman Raju, RH=Reduanul Haque, TK=Tania Khatun, ABA= Amatul Bushra AkhiMRR=Mahfuzur Rahman Raju, RH=Reduanul Haque, TK=Tania Khatun, ABA= Amatul Bushra Akhi,</p>
 </div>
<p>        
    <div style="float: left;">
       <p style="font-weight: bold;">DR. S M Aminul Islam</p>  
       <small><p>Member, Examination Committee<br/>Associate Head CSE,Permanent Campus</p></small>

    </div>
   <div style="float: right;">
       <p style="font-weight: bold;">DR. S M Aminul Islam</p>  
       <small><p>Member, Examination Committee<br/>Associate Head CSE,Permanent Campus</p></small>

    </div>        
</p>
EOF;




// column titles
$header = array('Time Slot', 'Day', 'LT', 'Course Code', 'Course Title', 'Invigilator', 'Room', 'Size');
$data = $pdf->LoadData('data/table_data_demo.txt');

// print colored table
$pdf->ColoredTable($header, $data);

// ---------------------------------------------------------
// close and output PDF document
$pdf->writeHTML($html, true, false, true, false, '');
$pdf->Output('Invigilator Routine.pdf', 'I');

//============================================================+
// END OF FILE
//============================================================+
