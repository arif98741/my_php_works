<!DOCTYPE html>
<html lang="en-US">
    <head>
        <title>Ajax Learning Point</title>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
        <meta name="description" content="">
        <meta name="author" content="Ariful Islam">
        <meta name="author_uri" content="http://facebook.com/arifulislammmc007">
        <!--        Bootstrap CSS Class-->
        <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
        <!--        Font awesome css library for using icons inside webpage-->
        <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css">
        <link rel="icon" href="img/favicon.ico">
        <link href="css/ie10-viewport-bug-workaround.css" rel="stylesheet">

        <link href="css/dashboard.css" rel="stylesheet">

        <script src="js/ie-emulation-modes-warning.js"></script>
        <link href="css/carousel.css" rel="stylesheet">
        <link href="css/signin.css" rel="stylesheet">
        <script src="js/jquery.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
    </head>
    <body>
        <nav class="navbar navbar-default navbar-fixed-top">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="index.php">File Management</a>
                </div>
                <div id="navbar" class="navbar-collapse collapse">
                    <ul class="nav navbar-nav">
                        <li class="active"><a href="index.php"><i class="fa fa-home"></i>&nbsp;Home</a></li>
                        <li><a href="gallary.php"><i class="fa fa-image"></i>&nbsp;Gallary</a></li>
                        <li><a href="notice.php"><i class="fa fa-list fa-envelope-open"></i>&nbsp;Notice Board</a></li>
                        <li><a href="events.php"><i class="fa fa-calendar"></i>&nbsp;Events</a></li>
                    </ul>
                    <ul class="nav navbar-nav navbar-right">
                        <li><a href="about.php">About</a></li>
                        <li><a href="contact.php">Contact</a></li>
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Login <span class="caret"></span></a>
                            <ul class="dropdown-menu">
                                <li><a href="teacher_signin.php">Teacher login</a></li>
                                <li><a href="signin.php">Student Login</a></li>
                                <li role="separator" class="divider"></li>
                                <li><a href="#">Separated link</a></li>
                                <li><a href="#">One more separated link</a></li>
                            </ul>
                        </li>
                    </ul>
                </div><!--/.nav-collapse -->
            </div>
        </nav>
        <div class="container-fluid">
            <div class="row">
                <div class="col-sm-3 col-md-2 sidebar">
                    <ul class="nav nav-sidebar">
                        <li class="active"><a href="#">Overview <span class="sr-only">(current)</span></a></li>
                        <li><a href="index.php">Home</a></li>
                        <li><a href="gallary.php">Gallary</a></li>
                        <li><a href="notice.php">Notice Board</a></li>
                        <li><a href="events.php">Events</a></li>
                        <li><a href="teacher_signin.php">Teacher login</a></li>
                        <li><a href="signin.php">Student Login</a></li>
                        <li><a href="about.php">About</a></li>
                        <li><a href="contact.php">Contact</a></li>
                    </ul>
                    <!-- <ul class="nav nav-sidebar">
                      <li><a href="">Nav item again</a></li>
                      <li><a href="">One more nav</a></li>
                      <li><a href="">Another nav item</a></li>
                    </ul>-->
                </div>
            </div>
            <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
            </div>

    </body>

</html>