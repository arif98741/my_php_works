<?php include 'inc/header.php'; ?>
<style>
    th{
        text-align: center;
    }
</style>
<div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">

    <div class="col-md-12">
        <div class="panel ">
            <div class="panel-heading bg-primary">
                <h3 class="">This is panel heading.</h3>
            </div>
            <div class="panel-body">

                <table class="table table-bordered table-responsive table-hover" style="text-align: center;">
                    <a class="pull-right"><i class="fa fa-print btn btn-info"></i></a>
                    <p class="pull-right"><i class="fa fa-download btn btn-success"></i></p>

                    <thead>
                        <tr>
                            <th><i class="fa fa-user"></i>&nbsp;Name</th>
                            <th><i class="fa fa-list"></i>&nbsp;ID</th>
                            <th><i class="fa fa-yahoo"></i>&nbsp;Department</th>
                            <th><i class="fa fa-envelope-open"></i>&nbsp;Semester</th>
                            <th><i class="fa fa-windows"></i>&nbsp;Contact</th>
                            <th><i class="fa fa-users"></i>&nbsp;Address</th>
                            <th><i class="fa fa-cog"></i>&nbsp;Action</th>

                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        for ($i = 0; $i < 20; $i++) {
                            ?>
                            <tr>
                                <td>Ariful Islam</td>
                                <td>161-15-946</td>
                                <td>CSE</td>
                                <td>Semester <?php echo $i + 1; ?></td>
                                <td>01750-840217</td>
                                <td>Ellenga, Tangail, Fultala</td>
                                <td><a href=""><i class="fa fa-pencil btn btn-success"></i>&nbsp;</a><a href=""><i class="fa fa-refresh btn btn-warning"></i>&nbsp;</a><a href=""><i class="fa fa-trash btn btn-danger"></i>&nbsp;</a></td>

                            </tr>
                        <?php } ?>



                    </tbody>
                    <thead>
                        <tr>
                            <th><i class="fa fa-user"></i>&nbsp;Name</th>
                            <th><i class="fa fa-list"></i>&nbsp;ID</th>
                            <th><i class="fa fa-yahoo"></i>&nbsp;Department</th>
                            <th><i class="fa fa-envelope-open"></i>&nbsp;Semester</th>
                            <th><i class="fa fa-windows"></i>&nbsp;Contact</th>
                            <th><i class="fa fa-users"></i>&nbsp;Address</th>
                            <th><i class="fa fa-cog"></i>&nbsp;Action</th>

                        </tr>
                    </thead>



                </table>

            </div>
        </div>

    </div>
</div>
