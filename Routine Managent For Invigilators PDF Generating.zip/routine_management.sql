-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jul 27, 2017 at 02:14 PM
-- Server version: 10.1.19-MariaDB
-- PHP Version: 5.6.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `routine_management`
--

-- --------------------------------------------------------

--
-- Table structure for table `routine`
--

CREATE TABLE `routine` (
  `id` int(11) NOT NULL,
  `Time Slot` timestamp(3) NOT NULL DEFAULT CURRENT_TIMESTAMP
) ;

--
-- Dumping data for table `routine`
--

INSERT INTO `routine` (`id`, `Time Slot`, `Day`, `LT`, `CCode`, `CTitle`, `Invigilator`, `Room`, `Size`) VALUES
(2, '2017-07-27 10:17:14.455', 'Saturday', 'LJFJ', 'CSEXXX', 'SDFSADJFSAL ', 'SAJDFAS FSDALF', 303, 60),
(3, '2017-07-27 10:38:27.073', 'Sunday', 'L3T4', 'CSEXXX', 'Computer Science', 'XXXXXX XXXXXX', 301, 80),
(4, '2017-07-27 10:38:32.867', 'Monday', 'L3T4', 'CSEXXX', 'Algorithms', 'XXXXXX XXXXXX', 301, 80),
(5, '2017-07-27 10:38:49.775', 'Tuesday', 'L3T4', 'CSEXXX', 'Database Analysis', 'XXXXXX XXXXXX', 301, 80),
(6, '2017-07-27 10:39:05.082', 'Wednesday', 'L3T4', 'CSEXXX', 'Electrical Circuits and Analysis', 'XXXXXX XXXXXX', 301, 80),
(7, '2017-07-27 10:49:37.599', 'Thusday', 'L3T4', 'CSEXXX', 'Physics ||', 'XXXXXX XXXXXX', 301, 80),
(8, '2017-07-27 10:49:54.298', 'Friday', 'L3T4', 'CSEXXX', 'Physics |', 'XXXXXX XXXXXX', 301, 80),
(9, '2017-07-27 10:55:34.339', 'Sunday', 'L3T4', 'CSEXXX', '', 'XXXXXX XXXXXX', 301, 80),
(10, '2017-07-26 06:31:20.000', 'Tuesday', 'L3T4', 'CSEXXX', 'XXXXX XxXXX', 'XXXXXX XXXXXX', 301, 80),
(11, '2017-07-26 18:00:00.000', 'Tuesday', 'L3T4', 'CSEXXX', 'XXXXX XxXXX', 'XXXXXX XXXXXX', 301, 80),
(12, '2017-07-19 00:17:17.000', 'Thusday', 'L3T4', 'CSEXXX', 'XXXXX XxXXX', 'XXXXXX XXXXXX', 301, 80),
(13, '2017-07-28 01:00:00.000', 'Saturday', 'L3T4', 'CSEXXX', 'XXXXX XxXXX', 'XXXXXX XXXXXX', 301, 80),
(14, '2017-07-27 10:17:14.455', 'Saturday', 'LJFJ', 'CSEXXX', 'SDFSADJFSAL ', 'SAJDFAS FSDALF', 303, 60),
(15, '2017-07-27 10:38:32.867', 'Monday', 'L3T4', 'CSEXXX', 'Algorithms', 'XXXXXX XXXXXX', 301, 80),
(16, '2017-07-27 10:38:49.775', 'Tuesday', 'L3T4', 'CSEXXX', 'Database Analysis', 'XXXXXX XXXXXX', 301, 80),
(17, '2017-07-27 10:39:05.082', 'Wednesday', 'L3T4', 'CSEXXX', 'Electrical Circuits and Analysis', 'XXXXXX XXXXXX', 301, 80),
(18, '2017-07-27 10:49:54.298', 'Friday', 'L3T4', 'CSEXXX', 'Physics |', 'XXXXXX XXXXXX', 301, 80);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `routine`
--
ALTER TABLE `routine`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
