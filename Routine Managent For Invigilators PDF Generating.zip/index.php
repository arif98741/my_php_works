<?php include 'inc/header.php'; ?>
<div class="panel" style="max-width: 280px; margin: 0 auto; margin-top: 10px;">
    <a href="http://localhost/practise/pdf/examples/example_011.php" class="btn btn-primary" target="_blank"><i class="fa fa-spinner fa-file-image-o fa-fw"></i> Show PDF</a> 
    <a href="http://localhost/practise/pdf/examples/example_011.php" class="btn btn-success" target="_blank"><i class="fa fa-download fa-spin"></i> Download PDF</a> 

</div>
<div class="container"> <br/>
    <div class="panel">
        <div class="panel-heading">
            <h4>Table Data</h4>

        </div>
        <div class="panel-body">

            <table class="table table-bordered table-responsive table-hover bg-primary" style="max-width: 80%; margin: 0 auto;">
                <thead>
                    <tr class="bg-primary" style="text-align: center;">
                        <th>Time Slot</th>
                        <th>Day</th>
                        <th>LT</th>
                        <th>Course Code</th>
                        <th>Course Title</th>
                        <th>Invigilator</th>
                        <th>Room</th>
                        <th>Size</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $con = new mysqli('localhost', 'root', '', 'routine_management');
                    if ($con) {
                        $sql = "select * from routine"; // this query for fetching data from server
                        $query = $con->query($sql);
                        if ($query) {
                            while ($row = $query->fetch_assoc()) {
                                ?>
                                <tr>
                                    <td><?php echo date('d-m-y', strtotime($row['Time Slot'])); ?></td>
                                    <td><?php echo $row['Day']; ?></td>
                                    <td><?php echo $row['LT']; ?></td>
                                    <td><?php echo $row['CCode']; ?></td>
                                    <td><?php echo $row['CTitle']; ?></td>
                                    <td><?php echo $row['Invigilator']; ?></td>
                                    <td><?php echo $row['Room']; ?></td>
                                    <td><?php echo $row['Size']; ?></td>


                                </tr>

                                <?php
                            }
                        }
                    }
                    ?>

                </tbody>
            </table>
        </div>
        <div class="panel-footer bg-info">
            <h5 class="pull-left">&copy; Copyright 2017; Ariful Islam</h5>
            <h5 class="pull-right">All Rights Reserved By Ariful Islam</h5>
        </div>
    </div>
</div>


<?php include 'inc/footer.php'; ?>